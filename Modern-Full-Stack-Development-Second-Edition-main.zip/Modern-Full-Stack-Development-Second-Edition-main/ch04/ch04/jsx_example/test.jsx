const button = <MaterialButton color="red"
  onClick="alert('clicked');">
  Click Me
</MaterialButton>;
