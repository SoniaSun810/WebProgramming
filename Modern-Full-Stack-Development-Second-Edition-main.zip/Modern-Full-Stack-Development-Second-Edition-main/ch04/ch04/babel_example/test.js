const newArray = [ 44, 55, 66].map((num) => n * 2);
