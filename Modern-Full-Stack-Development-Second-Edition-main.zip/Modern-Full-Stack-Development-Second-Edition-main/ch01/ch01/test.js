const a = 5;
const b = 3;
const c = a * b;
console.log(`${a} * ${b} = ${c}`);
