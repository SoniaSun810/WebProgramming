export default function getB() { return 30; }
