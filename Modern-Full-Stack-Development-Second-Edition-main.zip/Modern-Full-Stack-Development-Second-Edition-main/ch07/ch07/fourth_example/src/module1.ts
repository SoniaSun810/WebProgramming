export default function getA() { return 20; }
