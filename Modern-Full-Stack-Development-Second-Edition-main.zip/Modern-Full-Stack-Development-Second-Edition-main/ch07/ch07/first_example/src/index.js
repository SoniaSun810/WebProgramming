let a = 2;
let b = 5;
let c = a * b;
alert(c);
