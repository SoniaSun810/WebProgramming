function sayHi(humanName: string) {
  alert(`Hello, ${humanName}!`);
}
sayHi("Luke Skywalker");
