export const config: { serverAddress: string, userEmail: string } =
{
  serverAddress : "http://localhost",
  userEmail : "soniasun0925@gmail.com"
};
