import getA from "./module1";
import getB from "./module2";

alert(getA() + getB());
console.log("getA + getB")
