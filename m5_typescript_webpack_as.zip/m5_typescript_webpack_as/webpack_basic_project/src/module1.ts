export default function getA() 
{ 
    console.log("getA")
    return 100; }
