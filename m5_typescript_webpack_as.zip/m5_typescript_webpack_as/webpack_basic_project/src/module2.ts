export default function getB() { 
    console.log("getB")
    return 99; }
